package com.bouali.gestiondestock.model;

public enum EtatCommande {

  EN_PREPARATION,
  VALIDEE,
  LIVREE
}
