package com.bouali.gestiondestock.model;

public enum TypeMvtStk {

  ENTREE, SORTIE, CORRECTION_POS, CORRECTION_NEG
}
