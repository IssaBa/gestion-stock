package com.bouali.gestiondestock.model;

public enum SourceMvtStk {

  COMMANDE_CLIENT,
  COMMANDE_FOURNISSEUR,
  VENTE

}
