package com.bouali.gestiondestock.validator;

import com.bouali.gestiondestock.dto.LigneCommandeClientDto;
import java.util.ArrayList;
import java.util.List;

public class LigneCommandeClientValidator {

  // TODO to be implemented
  public static List<String> validate(LigneCommandeClientDto dto) {
    List<String> errors = new ArrayList<>();
    return errors;
  }

}
