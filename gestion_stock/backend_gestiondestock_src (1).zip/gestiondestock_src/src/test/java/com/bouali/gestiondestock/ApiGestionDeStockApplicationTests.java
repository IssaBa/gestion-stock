package com.bouali.gestiondestock;

//@SpringBootTest
class ApiGestionDeStockApplicationTests {

  // @Test
  void contextLoads() {
  }

}
